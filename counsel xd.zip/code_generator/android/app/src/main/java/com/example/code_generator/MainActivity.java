package com.example.code_generator;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
