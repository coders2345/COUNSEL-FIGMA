import 'package:flutter/material.dart';

class XDNext extends StatelessWidget {
  XDNext({
    Key? key,
  }) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return Stack(
      children: <Widget>[
        Container(
          decoration: BoxDecoration(
            color: const Color(0xffbf0065),
            borderRadius: BorderRadius.circular(34.0),
          ),
        ),
        Align(
          alignment: Alignment(0.003, -0.014),
          child: SizedBox(
            width: 98.0,
            height: 61.0,
            child: Text(
              'Next',
              style: TextStyle(
                fontFamily: 'Calibri',
                fontSize: 50,
                color: const Color(0xffffffff),
                fontWeight: FontWeight.w700,
              ),
              textAlign: TextAlign.center,
              softWrap: false,
            ),
          ),
        ),
      ],
    );
  }
}
