import 'package:flutter/material.dart';
import 'package:adobe_xd/pinned.dart';
import 'package:flutter_svg/flutter_svg.dart';

class XDNewsFeed1 extends StatelessWidget {
  XDNewsFeed1({
    Key? key,
  }) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xffffffff),
      body: Stack(
        children: <Widget>[
          Padding(
            padding: EdgeInsets.fromLTRB(32.0, 84.0, 32.0, -754.0),
            child:
                // Adobe XD layer: 'News' (group)
                Stack(
              children: <Widget>[
                Pinned.fromPins(
                  Pin(start: 0.0, end: 0.0),
                  Pin(size: 419.0, start: 0.0),
                  child:
                      // Adobe XD layer: 'New' (group)
                      Stack(
                    children: <Widget>[
                      Pinned.fromPins(
                        Pin(start: 0.0, end: 0.0),
                        Pin(size: 220.0, start: 0.0),
                        child:
                            // Adobe XD layer: 'Rectangle 169' (shape)
                            Container(
                          color: const Color(0xffbce0fd),
                        ),
                      ),
                      Pinned.fromPins(
                        Pin(start: 0.0, end: 0.0),
                        Pin(size: 60.0, middle: 0.6797),
                        child:
                            // Adobe XD layer: 'Excepteur sint occa…' (text)
                            Text(
                          'Excepteur sint occaecat cupidatat non proident.',
                          style: TextStyle(
                            fontFamily: 'Arial',
                            fontSize: 20,
                            color: const Color(0xff2699fb),
                            fontWeight: FontWeight.w700,
                            height: 1.5,
                          ),
                          textHeightBehavior: TextHeightBehavior(
                              applyHeightToFirstAscent: false),
                        ),
                      ),
                      Pinned.fromPins(
                        Pin(start: 0.0, end: 0.0),
                        Pin(size: 67.0, end: 40.0),
                        child:
                            // Adobe XD layer: 'Excepteur sint occa…' (text)
                            Text(
                          'Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est eopksio laborum.',
                          style: TextStyle(
                            fontFamily: 'Arial',
                            fontSize: 14,
                            color: const Color(0xff2699fb),
                            height: 1.7142857142857142,
                          ),
                          textHeightBehavior: TextHeightBehavior(
                              applyHeightToFirstAscent: false),
                        ),
                      ),
                      Align(
                        alignment: Alignment(0.041, 1.0),
                        child: SizedBox(
                          width: 69.0,
                          height: 17.0,
                          child:
                              // Adobe XD layer: 'time' (group)
                              Stack(
                            children: <Widget>[
                              Pinned.fromPins(
                                Pin(size: 43.0, end: 0.0),
                                Pin(start: 0.0, end: 1.0),
                                child:
                                    // Adobe XD layer: '1h ago' (text)
                                    Text(
                                  '1h ago',
                                  style: TextStyle(
                                    fontFamily: 'Arial',
                                    fontSize: 14,
                                    color: const Color(0xff2699fb),
                                    height: 1.7142857142857142,
                                  ),
                                  textHeightBehavior: TextHeightBehavior(
                                      applyHeightToFirstAscent: false),
                                  softWrap: false,
                                ),
                              ),
                              Pinned.fromPins(
                                Pin(size: 16.0, start: 0.0),
                                Pin(start: 1.0, end: 0.0),
                                child:
                                    // Adobe XD layer: 'Symbol 22 – 10' (group)
                                    Stack(
                                  children: <Widget>[
                                    SizedBox.expand(
                                        child:
                                            // Adobe XD layer: 'Path 13' (shape)
                                            SvgPicture.string(
                                      _svg_cwd6qx,
                                      allowDrawingOutsideViewBox: true,
                                      fit: BoxFit.fill,
                                    )),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                      Align(
                        alignment: Alignment.bottomLeft,
                        child: SizedBox(
                          width: 95.0,
                          height: 17.0,
                          child:
                              // Adobe XD layer: 'link' (group)
                              Stack(
                            children: <Widget>[
                              Pinned.fromPins(
                                Pin(size: 69.0, end: 0.0),
                                Pin(start: 0.0, end: 1.0),
                                child:
                                    // Adobe XD layer: 'adobe.com' (text)
                                    Text(
                                  'adobe.com',
                                  style: TextStyle(
                                    fontFamily: 'Arial',
                                    fontSize: 14,
                                    color: const Color(0xff2699fb),
                                    height: 1.7142857142857142,
                                  ),
                                  textHeightBehavior: TextHeightBehavior(
                                      applyHeightToFirstAscent: false),
                                  softWrap: false,
                                ),
                              ),
                              Pinned.fromPins(
                                Pin(size: 16.0, start: 0.0),
                                Pin(start: 1.0, end: 0.0),
                                child:
                                    // Adobe XD layer: 'Symbol 5 – 8' (group)
                                    Stack(
                                  children: <Widget>[
                                    SizedBox.expand(
                                        child:
                                            // Adobe XD layer: 'Path 4' (shape)
                                            SvgPicture.string(
                                      _svg_uy19g0,
                                      allowDrawingOutsideViewBox: true,
                                      fit: BoxFit.fill,
                                    )),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                Pinned.fromPins(
                  Pin(start: 0.0, end: 0.0),
                  Pin(size: 419.0, middle: 0.5),
                  child:
                      // Adobe XD layer: 'New' (group)
                      Stack(
                    children: <Widget>[
                      Pinned.fromPins(
                        Pin(start: 0.0, end: 0.0),
                        Pin(size: 220.0, start: 0.0),
                        child:
                            // Adobe XD layer: 'Rectangle 169' (shape)
                            Container(
                          color: const Color(0xffbce0fd),
                        ),
                      ),
                      Pinned.fromPins(
                        Pin(start: 0.0, end: 0.0),
                        Pin(size: 60.0, middle: 0.6797),
                        child:
                            // Adobe XD layer: 'Excepteur sint occa…' (text)
                            Text(
                          'Excepteur sint occaecat cupidatat non proident.',
                          style: TextStyle(
                            fontFamily: 'Arial',
                            fontSize: 20,
                            color: const Color(0xff2699fb),
                            fontWeight: FontWeight.w700,
                            height: 1.5,
                          ),
                          textHeightBehavior: TextHeightBehavior(
                              applyHeightToFirstAscent: false),
                        ),
                      ),
                      Pinned.fromPins(
                        Pin(start: 0.0, end: 0.0),
                        Pin(size: 67.0, end: 40.0),
                        child:
                            // Adobe XD layer: 'Excepteur sint occa…' (text)
                            Text(
                          'Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est eopksio laborum.',
                          style: TextStyle(
                            fontFamily: 'Arial',
                            fontSize: 14,
                            color: const Color(0xff2699fb),
                            height: 1.7142857142857142,
                          ),
                          textHeightBehavior: TextHeightBehavior(
                              applyHeightToFirstAscent: false),
                        ),
                      ),
                      Align(
                        alignment: Alignment(0.041, 1.0),
                        child: SizedBox(
                          width: 69.0,
                          height: 17.0,
                          child:
                              // Adobe XD layer: 'time' (group)
                              Stack(
                            children: <Widget>[
                              Pinned.fromPins(
                                Pin(size: 43.0, end: 0.0),
                                Pin(start: 0.0, end: 1.0),
                                child:
                                    // Adobe XD layer: '1h ago' (text)
                                    Text(
                                  '1h ago',
                                  style: TextStyle(
                                    fontFamily: 'Arial',
                                    fontSize: 14,
                                    color: const Color(0xff2699fb),
                                    height: 1.7142857142857142,
                                  ),
                                  textHeightBehavior: TextHeightBehavior(
                                      applyHeightToFirstAscent: false),
                                  softWrap: false,
                                ),
                              ),
                              Pinned.fromPins(
                                Pin(size: 16.0, start: 0.0),
                                Pin(start: 1.0, end: 0.0),
                                child:
                                    // Adobe XD layer: 'Symbol 22 – 11' (group)
                                    Stack(
                                  children: <Widget>[
                                    SizedBox.expand(
                                        child:
                                            // Adobe XD layer: 'Path 13' (shape)
                                            SvgPicture.string(
                                      _svg_cwd6qx,
                                      allowDrawingOutsideViewBox: true,
                                      fit: BoxFit.fill,
                                    )),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                      Align(
                        alignment: Alignment.bottomLeft,
                        child: SizedBox(
                          width: 95.0,
                          height: 17.0,
                          child:
                              // Adobe XD layer: 'link' (group)
                              Stack(
                            children: <Widget>[
                              Pinned.fromPins(
                                Pin(size: 69.0, end: 0.0),
                                Pin(start: 0.0, end: 1.0),
                                child:
                                    // Adobe XD layer: 'adobe.com' (text)
                                    Text(
                                  'adobe.com',
                                  style: TextStyle(
                                    fontFamily: 'Arial',
                                    fontSize: 14,
                                    color: const Color(0xff2699fb),
                                    height: 1.7142857142857142,
                                  ),
                                  textHeightBehavior: TextHeightBehavior(
                                      applyHeightToFirstAscent: false),
                                  softWrap: false,
                                ),
                              ),
                              Pinned.fromPins(
                                Pin(size: 16.0, start: 0.0),
                                Pin(start: 1.0, end: 0.0),
                                child:
                                    // Adobe XD layer: 'Symbol 5 – 9' (group)
                                    Stack(
                                  children: <Widget>[
                                    SizedBox.expand(
                                        child:
                                            // Adobe XD layer: 'Path 4' (shape)
                                            SvgPicture.string(
                                      _svg_uy19g0,
                                      allowDrawingOutsideViewBox: true,
                                      fit: BoxFit.fill,
                                    )),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                Pinned.fromPins(
                  Pin(start: 0.0, end: 0.0),
                  Pin(size: 419.0, end: 0.0),
                  child:
                      // Adobe XD layer: 'New' (group)
                      Stack(
                    children: <Widget>[
                      Pinned.fromPins(
                        Pin(start: 0.0, end: 0.0),
                        Pin(size: 220.0, start: 0.0),
                        child:
                            // Adobe XD layer: 'Rectangle 169' (shape)
                            Container(
                          color: const Color(0xffbce0fd),
                        ),
                      ),
                      Pinned.fromPins(
                        Pin(start: 0.0, end: 0.0),
                        Pin(size: 60.0, middle: 0.6797),
                        child:
                            // Adobe XD layer: 'Excepteur sint occa…' (text)
                            Text(
                          'Excepteur sint occaecat cupidatat non proident.',
                          style: TextStyle(
                            fontFamily: 'Arial',
                            fontSize: 20,
                            color: const Color(0xff2699fb),
                            fontWeight: FontWeight.w700,
                            height: 1.5,
                          ),
                          textHeightBehavior: TextHeightBehavior(
                              applyHeightToFirstAscent: false),
                        ),
                      ),
                      Pinned.fromPins(
                        Pin(start: 0.0, end: 0.0),
                        Pin(size: 67.0, end: 40.0),
                        child:
                            // Adobe XD layer: 'Excepteur sint occa…' (text)
                            Text(
                          'Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est eopksio laborum.',
                          style: TextStyle(
                            fontFamily: 'Arial',
                            fontSize: 14,
                            color: const Color(0xff2699fb),
                            height: 1.7142857142857142,
                          ),
                          textHeightBehavior: TextHeightBehavior(
                              applyHeightToFirstAscent: false),
                        ),
                      ),
                      Align(
                        alignment: Alignment(0.041, 1.0),
                        child: SizedBox(
                          width: 69.0,
                          height: 17.0,
                          child:
                              // Adobe XD layer: 'time' (group)
                              Stack(
                            children: <Widget>[
                              Pinned.fromPins(
                                Pin(size: 43.0, end: 0.0),
                                Pin(start: 0.0, end: 1.0),
                                child:
                                    // Adobe XD layer: '1h ago' (text)
                                    Text(
                                  '1h ago',
                                  style: TextStyle(
                                    fontFamily: 'Arial',
                                    fontSize: 14,
                                    color: const Color(0xff2699fb),
                                    height: 1.7142857142857142,
                                  ),
                                  textHeightBehavior: TextHeightBehavior(
                                      applyHeightToFirstAscent: false),
                                  softWrap: false,
                                ),
                              ),
                              Pinned.fromPins(
                                Pin(size: 16.0, start: 0.0),
                                Pin(start: 1.0, end: 0.0),
                                child:
                                    // Adobe XD layer: 'Symbol 22 – 12' (group)
                                    Stack(
                                  children: <Widget>[
                                    SizedBox.expand(
                                        child:
                                            // Adobe XD layer: 'Path 13' (shape)
                                            SvgPicture.string(
                                      _svg_cwd6qx,
                                      allowDrawingOutsideViewBox: true,
                                      fit: BoxFit.fill,
                                    )),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                      Align(
                        alignment: Alignment.bottomLeft,
                        child: SizedBox(
                          width: 95.0,
                          height: 17.0,
                          child:
                              // Adobe XD layer: 'link' (group)
                              Stack(
                            children: <Widget>[
                              Pinned.fromPins(
                                Pin(size: 69.0, end: 0.0),
                                Pin(start: 0.0, end: 1.0),
                                child:
                                    // Adobe XD layer: 'adobe.com' (text)
                                    Text(
                                  'adobe.com',
                                  style: TextStyle(
                                    fontFamily: 'Arial',
                                    fontSize: 14,
                                    color: const Color(0xff2699fb),
                                    height: 1.7142857142857142,
                                  ),
                                  textHeightBehavior: TextHeightBehavior(
                                      applyHeightToFirstAscent: false),
                                  softWrap: false,
                                ),
                              ),
                              Pinned.fromPins(
                                Pin(size: 16.0, start: 0.0),
                                Pin(start: 1.0, end: 0.0),
                                child:
                                    // Adobe XD layer: 'Symbol 5 – 10' (group)
                                    Stack(
                                  children: <Widget>[
                                    SizedBox.expand(
                                        child:
                                            // Adobe XD layer: 'Path 4' (shape)
                                            SvgPicture.string(
                                      _svg_uy19g0,
                                      allowDrawingOutsideViewBox: true,
                                      fit: BoxFit.fill,
                                    )),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          Pinned.fromPins(
            Pin(start: 0.0, end: 0.0),
            Pin(size: 68.0, start: 0.0),
            child:
                // Adobe XD layer: 'Navigation Bar' (group)
                Stack(
              children: <Widget>[
                Pinned.fromPins(
                  Pin(start: 0.0, end: 0.0),
                  Pin(size: 20.0, start: 0.0),
                  child:
                      // Adobe XD layer: 'Rectangle 68' (shape)
                      Container(
                    decoration: BoxDecoration(),
                  ),
                ),
                // Adobe XD layer: 'Rectangle 69' (shape)
                Container(
                  decoration: BoxDecoration(),
                  margin: EdgeInsets.fromLTRB(0.0, 20.0, 0.0, 0.0),
                ),
                Pinned.fromPins(
                  Pin(size: 3.0, end: 16.0),
                  Pin(size: 15.0, middle: 0.6981),
                  child:
                      // Adobe XD layer: 'More' (group)
                      Stack(
                    children: <Widget>[
                      // Adobe XD layer: 'Union 1' (group)
                      Stack(
                        children: <Widget>[
                          Pinned.fromPins(
                            Pin(start: 0.0, end: 0.0),
                            Pin(size: 3.0, start: 0.0),
                            child:
                                // Adobe XD layer: 'Ellipse 3' (shape)
                                Container(
                              decoration: BoxDecoration(
                                color: const Color(0xff2699fb),
                                borderRadius: BorderRadius.all(
                                    Radius.elliptical(9999.0, 9999.0)),
                              ),
                            ),
                          ),
                          Pinned.fromPins(
                            Pin(start: 0.0, end: 0.0),
                            Pin(size: 3.0, middle: 0.5),
                            child:
                                // Adobe XD layer: 'Ellipse 4' (shape)
                                Container(
                              decoration: BoxDecoration(
                                color: const Color(0xff2699fb),
                                borderRadius: BorderRadius.all(
                                    Radius.elliptical(9999.0, 9999.0)),
                              ),
                            ),
                          ),
                          Pinned.fromPins(
                            Pin(start: 0.0, end: 0.0),
                            Pin(size: 3.0, end: 0.0),
                            child:
                                // Adobe XD layer: 'Ellipse 5' (shape)
                                Container(
                              decoration: BoxDecoration(
                                color: const Color(0xff2699fb),
                                borderRadius: BorderRadius.all(
                                    Radius.elliptical(9999.0, 9999.0)),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                Align(
                  alignment: Alignment(0.003, 0.346),
                  child: SizedBox(
                    width: 42.0,
                    height: 16.0,
                    child:
                        // Adobe XD layer: 'NEWS' (text)
                        Text(
                      'NEWS',
                      style: TextStyle(
                        fontFamily: 'Arial',
                        fontSize: 14,
                        color: const Color(0xff2699fb),
                        fontWeight: FontWeight.w700,
                      ),
                      textAlign: TextAlign.center,
                      softWrap: false,
                    ),
                  ),
                ),
                Pinned.fromPins(
                  Pin(size: 16.0, start: 16.0),
                  Pin(size: 16.0, middle: 0.6923),
                  child:
                      // Adobe XD layer: 'Menu' (group)
                      Stack(
                    children: <Widget>[
                      // Adobe XD layer: 'Rectangle 175' (shape)
                      Container(
                        decoration: BoxDecoration(),
                      ),
                      Padding(
                        padding: EdgeInsets.symmetric(
                            horizontal: 0.0, vertical: 1.0),
                        child:
                            // Adobe XD layer: 'Union 4' (group)
                            Stack(
                          children: <Widget>[
                            Pinned.fromPins(
                              Pin(start: 0.0, end: 0.0),
                              Pin(size: 2.0, start: 0.0),
                              child:
                                  // Adobe XD layer: 'Rectangle 172' (shape)
                                  Container(
                                color: const Color(0xff2699fb),
                              ),
                            ),
                            Pinned.fromPins(
                              Pin(start: 0.0, end: 0.0),
                              Pin(size: 2.0, middle: 0.5),
                              child:
                                  // Adobe XD layer: 'Rectangle 173' (shape)
                                  Container(
                                color: const Color(0xff2699fb),
                              ),
                            ),
                            Align(
                              alignment: Alignment.bottomLeft,
                              child:
                                  // Adobe XD layer: 'Rectangle 174' (shape)
                                  Container(
                                width: 8.0,
                                height: 2.0,
                                color: const Color(0xff2699fb),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

const String _svg_cwd6qx =
    '<svg viewBox="0.0 0.0 16.0 16.0" ><path  d="M 2.400000095367432 2.400000095367432 C 3.866666793823242 0.8000000715255737 5.733333587646484 0 8 0 C 10.26666641235352 0 12.13333415985107 0.8000000715255737 13.60000038146973 2.400000095367432 C 15.19999980926514 3.866666793823242 16 5.733333587646484 16 8 C 16 10.26666641235352 15.19999980926514 12.13333415985107 13.60000038146973 13.60000038146973 C 12.13333415985107 15.19999980926514 10.26666641235352 16 8 16 C 5.733333587646484 16 3.866666793823242 15.19999980926514 2.400000333786011 13.60000038146973 C 0.9333337545394897 12 0 10.26666641235352 0 8 C 0 5.733333587646484 0.8000000715255737 3.866666793823242 2.400000095367432 2.400000095367432 Z M 11.60000038146973 11.60000038146973 L 12.53333282470703 10.66666698455811 L 9.200000762939453 7.333333492279053 L 8 2 L 6.666666984558105 2 L 6.666666984558105 8 C 6.666666984558105 8.40000057220459 6.800000190734863 8.666666984558105 7.066667079925537 8.933333396911621 C 7.066667079925537 8.933333396911621 7.200000286102295 9.066666603088379 7.333333492279053 9.066666603088379 L 11.60000038146973 11.60000038146973 Z" fill="#2699fb" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_uy19g0 =
    '<svg viewBox="0.0 0.0 16.0 16.0" ><path  d="M 2.400000095367432 2.400000095367432 C 3.866666793823242 0.8000000715255737 5.733333587646484 0 8 0 C 10.26666641235352 0 12.13333415985107 0.8000000715255737 13.60000038146973 2.400000095367432 C 15.19999980926514 3.866666793823242 16 5.733333587646484 16 8 C 16 10.26666641235352 15.19999980926514 12.13333415985107 13.60000038146973 13.60000038146973 C 12.13333415985107 15.19999980926514 10.26666641235352 16 8 16 C 5.733333587646484 16 3.866666793823242 15.19999980926514 2.400000333786011 13.60000038146973 C 0.9333337545394897 12 0 10.26666641235352 0 8 C 0 5.733333587646484 0.8000000715255737 3.866666793823242 2.400000095367432 2.400000095367432 Z M 9.066667556762695 14.40000057220459 C 9.600000381469727 14.40000057220459 10.26666736602783 14 11.0666675567627 13.20000076293945 C 11.60000038146973 12.26666641235352 12 11.33333396911621 12 10.40000057220459 C 12 9.733333587646484 11.73333358764648 9.200000762939453 11.33333396911621 8.80000114440918 C 10.80000114440918 8.266666412353516 10.26666641235352 8 9.600000381469727 8 L 8.266666412353516 8 C 7.866666793823242 8 7.466666698455811 7.866666793823242 7.066667079925537 7.733333587646484 C 6.800000190734863 7.466666698455811 6.666666984558105 7.200000286102295 6.666666984558105 6.800000190734863 C 6.666666984558105 6.533333778381348 6.800000190734863 6.399999618530273 6.933333396911621 6.266666412353516 C 7.066666603088379 6.133333206176758 7.333333492279053 6 7.466666698455811 6 C 7.599999904632568 6 8 6.133333206176758 8.133333206176758 6.40000057220459 C 8.40000057220459 6.533333778381348 8.533333778381348 6.666666984558105 8.666666984558105 6.666666984558105 C 8.800000190734863 6.666666984558105 9.066667556762695 6.666666984558105 9.200000762939453 6.533333778381348 C 9.333333969116211 6.40000057220459 9.333333969116211 6.133333206176758 9.333333969116211 6 C 9.333333969116211 5.599999904632568 9.066667556762695 5.066666603088379 8.666666984558105 4.666666984558105 C 9.066667556762695 3.866666793823242 9.333333969116211 3.066666603088379 9.333333969116211 2.133333444595337 C 9.333333969116211 2 9.200000762939453 1.866666674613953 9.066667556762695 1.866666674613953 C 8.666666984558105 1.733333349227905 8.266666412353516 1.600000143051147 8 1.600000143051147 C 6.533333778381348 1.733333349227905 5.466666698455811 2 4.533333778381348 2.666666746139526 C 3.733333349227905 3.333333492279053 3.333333492279053 4.266666889190674 3.333333492279053 5.333333492279053 C 3.333333492279053 6.40000057220459 3.733333349227905 7.200000286102295 4.400000095367432 7.866666793823242 C 5.066666603088379 8.533333778381348 6 8.933334350585938 6.933333396911621 8.933334350585938 L 6.933333396911621 8.933334350585938 C 6.933333396911621 9.066667556762695 6.933333396911621 9.333333969116211 6.933333396911621 9.466667175292969 C 6.933333396911621 10.00000095367432 7.066666603088379 10.40000057220459 7.466666698455811 10.80000114440918 C 7.733333110809326 11.20000076293945 8.133333206176758 11.46666717529297 8.666666984558105 11.60000133514404 L 8.666666984558105 14.00000190734863 C 8.666666984558105 14.13333511352539 8.666666984558105 14.13333511352539 8.800000190734863 14.26666831970215 C 8.933333396911621 14.40000057220459 8.933333396911621 14.40000057220459 9.066667556762695 14.40000057220459 Z" fill="#2699fb" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
