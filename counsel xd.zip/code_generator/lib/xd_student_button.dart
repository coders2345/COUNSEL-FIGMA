import 'package:flutter/material.dart';
import 'package:adobe_xd/pinned.dart';

class XDStudentButton extends StatelessWidget {
  XDStudentButton({
    Key? key,
  }) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return Stack(
      children: <Widget>[
        Container(
          decoration: BoxDecoration(
            color: const Color(0xffbf0065),
            borderRadius: BorderRadius.circular(34.0),
          ),
        ),
        Pinned.fromPins(
          Pin(size: 164.0, start: 247.0),
          Pin(start: 35.0, endFraction: 0.2672),
          child: Text(
            'Student',
            style: TextStyle(
              fontFamily: 'Calibri',
              fontSize: 50,
              color: const Color(0xffffffff),
              fontWeight: FontWeight.w700,
            ),
            textAlign: TextAlign.center,
            softWrap: false,
          ),
        ),
      ],
    );
  }
}
