import 'package:flutter/material.dart';
import 'package:adobe_xd/pinned.dart';
import './xd_icon_ionic_md_arrow_round_back.dart';
import 'package:adobe_xd/page_link.dart';
import 'package:flutter_svg/flutter_svg.dart';

class XDMenu1 extends StatelessWidget {
  XDMenu1({
    Key? key,
  }) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xffffffff),
      body: Stack(
        children: <Widget>[
          Pinned.fromPins(
            Pin(size: 1080.0, end: -495.0),
            Pin(size: 1327.0, end: -239.0),
            child: Stack(
              children: <Widget>[
                Padding(
                  padding: EdgeInsets.fromLTRB(-6.0, 150.0, -668.0, -680.0),
                  child: Stack(
                    children: <Widget>[
                      Align(
                        alignment: Alignment.topRight,
                        child: Container(
                          width: 1215.0,
                          height: 1215.0,
                          decoration: BoxDecoration(
                            color: const Color(0x1a990050),
                            borderRadius: BorderRadius.all(
                                Radius.elliptical(9999.0, 9999.0)),
                          ),
                        ),
                      ),
                      Align(
                        alignment: Alignment.bottomLeft,
                        child: Container(
                          width: 1215.0,
                          height: 1215.0,
                          decoration: BoxDecoration(
                            color: const Color(0x1a990050),
                            borderRadius: BorderRadius.all(
                                Radius.elliptical(9999.0, 9999.0)),
                          ),
                        ),
                      ),
                      Pinned.fromPins(
                        Pin(size: 1215.0, end: 202.0),
                        Pin(size: 1215.0, middle: 0.5452),
                        child: Container(
                          decoration: BoxDecoration(
                            color: const Color(0x1a990050),
                            borderRadius: BorderRadius.all(
                                Radius.elliptical(9999.0, 9999.0)),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                Container(
                  decoration: BoxDecoration(
                    color: const Color(0xffffffff),
                    border:
                        Border.all(width: 1.0, color: const Color(0xff707070)),
                  ),
                ),
              ],
            ),
          ),
          Pinned.fromPins(
            Pin(start: 0.0, end: 0.0),
            Pin(size: 1093.0, start: 0.0),
            child: Stack(
              children: <Widget>[
                Padding(
                  padding: EdgeInsets.fromLTRB(-630.0, -863.0, -44.0, 99.0),
                  child: Transform.rotate(
                    angle: 0.1396,
                    child: Stack(
                      children: <Widget>[
                        Align(
                          alignment: Alignment.topRight,
                          child: Container(
                            width: 1215.0,
                            height: 1215.0,
                            decoration: BoxDecoration(
                              color: const Color(0x60990050),
                              borderRadius: BorderRadius.all(
                                  Radius.elliptical(9999.0, 9999.0)),
                            ),
                          ),
                        ),
                        Align(
                          alignment: Alignment.bottomLeft,
                          child: Container(
                            width: 1215.0,
                            height: 1215.0,
                            decoration: BoxDecoration(
                              color: const Color(0x60990050),
                              borderRadius: BorderRadius.all(
                                  Radius.elliptical(9999.0, 9999.0)),
                            ),
                          ),
                        ),
                        Pinned.fromPins(
                          Pin(size: 1215.0, end: 202.0),
                          Pin(size: 1215.0, middle: 0.5452),
                          child: Container(
                            decoration: BoxDecoration(
                              color: const Color(0x60990050),
                              borderRadius: BorderRadius.all(
                                  Radius.elliptical(9999.0, 9999.0)),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                Container(
                  decoration: BoxDecoration(
                    color: const Color(0xbfffffff),
                    border:
                        Border.all(width: 1.0, color: const Color(0xbf707070)),
                  ),
                ),
              ],
            ),
          ),
          Padding(
            padding: EdgeInsets.fromLTRB(46.0, 275.0, 46.0, 274.0),
            child: Stack(
              children: <Widget>[
                Pinned.fromPins(
                  Pin(start: 0.0, end: 0.0),
                  Pin(size: 187.0, start: 0.0),
                  child:
                      // Adobe XD layer: 'Me' (group)
                      Stack(
                    children: <Widget>[
                      // Adobe XD layer: 'Rectangle 510' (shape)
                      Container(
                        decoration: BoxDecoration(
                          color: const Color(0xfff8ecf2),
                          borderRadius: BorderRadius.circular(25.0),
                        ),
                      ),
                      Pinned.fromPins(
                        Pin(size: 171.0, end: 71.0),
                        Pin(size: 44.0, middle: 0.4825),
                        child:
                            // Adobe XD layer: 'John Doe' (text)
                            Text(
                          'John Doe',
                          style: TextStyle(
                            fontFamily: 'Arial',
                            fontSize: 40,
                            color: const Color(0xffbf0065),
                          ),
                          textAlign: TextAlign.right,
                          softWrap: false,
                        ),
                      ),
                      Align(
                        alignment: Alignment(-0.597, -0.007),
                        child: SizedBox(
                          width: 60.0,
                          height: 48.0,
                          child:
                              // Adobe XD layer: 'Me' (text)
                              Text(
                            'Me',
                            style: TextStyle(
                              fontFamily: 'Arial',
                              fontSize: 43,
                              color: const Color(0xff990050),
                              fontWeight: FontWeight.w700,
                            ),
                            softWrap: false,
                          ),
                        ),
                      ),
                      Pinned.fromPins(
                        Pin(size: 46.3, start: 69.0),
                        Pin(size: 46.1, middle: 0.5104),
                        child:
                            // Adobe XD layer: 'Symbol 144 – 4' (group)
                            Stack(
                          children: <Widget>[
                            // Adobe XD layer: 'Rectangle 324' (shape)
                            Container(
                              decoration: BoxDecoration(),
                            ),
                            SizedBox.expand(
                                child:
                                    // Adobe XD layer: 'Path 110' (shape)
                                    SvgPicture.string(
                              _svg_s3l5y1,
                              allowDrawingOutsideViewBox: true,
                              fit: BoxFit.fill,
                            )),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
                Pinned.fromPins(
                  Pin(start: 0.0, end: 0.0),
                  Pin(size: 187.0, start: 257.0),
                  child:
                      // Adobe XD layer: 'Notifications' (group)
                      Stack(
                    children: <Widget>[
                      // Adobe XD layer: 'Rectangle 507' (shape)
                      Container(
                        decoration: BoxDecoration(
                          color: const Color(0xfff8ecf2),
                          borderRadius: BorderRadius.circular(25.0),
                        ),
                      ),
                      Align(
                        alignment: Alignment(-0.495, -0.007),
                        child: SizedBox(
                          width: 260.0,
                          height: 48.0,
                          child:
                              // Adobe XD layer: 'Notifications' (text)
                              Text(
                            'Notifications',
                            style: TextStyle(
                              fontFamily: 'Arial',
                              fontSize: 43,
                              color: const Color(0xff990050),
                              fontWeight: FontWeight.w700,
                            ),
                            softWrap: false,
                          ),
                        ),
                      ),
                      Pinned.fromPins(
                        Pin(size: 46.0, end: 72.0),
                        Pin(size: 46.0, middle: 0.4894),
                        child:
                            // Adobe XD layer: 'All' (text)
                            Text(
                          'All',
                          style: TextStyle(
                            fontFamily: 'Arial',
                            fontSize: 41,
                            color: const Color(0xffbf0065),
                          ),
                          textAlign: TextAlign.right,
                          softWrap: false,
                        ),
                      ),
                      Pinned.fromPins(
                        Pin(size: 46.0, start: 69.0),
                        Pin(size: 46.3, middle: 0.5117),
                        child:
                            // Adobe XD layer: 'Notifications' (group)
                            Stack(
                          children: <Widget>[
                            // Adobe XD layer: 'Rectangle 479' (shape)
                            Container(
                              decoration: BoxDecoration(),
                            ),
                            SizedBox.expand(
                                child:
                                    // Adobe XD layer: 'Path 1' (shape)
                                    SvgPicture.string(
                              _svg_ekp3i,
                              allowDrawingOutsideViewBox: true,
                              fit: BoxFit.fill,
                            )),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
                Pinned.fromPins(
                  Pin(start: 0.0, end: 0.0),
                  Pin(size: 188.0, middle: 0.3331),
                  child:
                      // Adobe XD layer: 'General' (group)
                      Stack(
                    children: <Widget>[
                      // Adobe XD layer: 'Rectangle 513' (shape)
                      Container(
                        decoration: BoxDecoration(
                          color: const Color(0xfff8ecf2),
                          borderRadius: BorderRadius.circular(25.0),
                        ),
                      ),
                      Pinned.fromPins(
                        Pin(size: 46.0, start: 69.0),
                        Pin(size: 47.0, middle: 0.5106),
                        child:
                            // Adobe XD layer: 'Symbol 147 – 5' (group)
                            Stack(
                          children: <Widget>[
                            // Adobe XD layer: 'Rectangle 193' (shape)
                            Container(
                              decoration: BoxDecoration(),
                            ),
                            Padding(
                              padding: EdgeInsets.fromLTRB(0.2, 0.5, 2.0, 0.4),
                              child: SizedBox.expand(
                                  child:
                                      // Adobe XD layer: 'Path 104' (shape)
                                      SvgPicture.string(
                                _svg_pmxtx,
                                allowDrawingOutsideViewBox: true,
                                fit: BoxFit.fill,
                              )),
                            ),
                          ],
                        ),
                      ),
                      Align(
                        alignment: Alignment(-0.556, 0.0),
                        child: SizedBox(
                          width: 160.0,
                          height: 48.0,
                          child:
                              // Adobe XD layer: 'General' (text)
                              Text(
                            'General',
                            style: TextStyle(
                              fontFamily: 'Arial',
                              fontSize: 43,
                              color: const Color(0xff990050),
                              fontWeight: FontWeight.w700,
                            ),
                            softWrap: false,
                          ),
                        ),
                      ),
                      Pinned.fromPins(
                        Pin(size: 318.0, end: 74.0),
                        Pin(size: 44.0, middle: 0.4861),
                        child:
                            // Adobe XD layer: 'Compress Photos' (text)
                            Text(
                          'Compress Photos',
                          style: TextStyle(
                            fontFamily: 'Arial',
                            fontSize: 40,
                            color: const Color(0xffbf0065),
                          ),
                          textAlign: TextAlign.right,
                          softWrap: false,
                        ),
                      ),
                    ],
                  ),
                ),
                Pinned.fromPins(
                  Pin(start: 0.0, end: 0.0),
                  Pin(size: 187.0, middle: 0.5),
                  child:
                      // Adobe XD layer: 'Account' (group)
                      Stack(
                    children: <Widget>[
                      // Adobe XD layer: 'Rectangle 511' (shape)
                      Container(
                        decoration: BoxDecoration(
                          color: const Color(0xfff8ecf2),
                          borderRadius: BorderRadius.circular(25.0),
                        ),
                      ),
                      Align(
                        alignment: Alignment(-0.549, -0.007),
                        child: SizedBox(
                          width: 172.0,
                          height: 48.0,
                          child:
                              // Adobe XD layer: 'Account' (text)
                              Text(
                            'Account',
                            style: TextStyle(
                              fontFamily: 'Arial',
                              fontSize: 43,
                              color: const Color(0xff990050),
                              fontWeight: FontWeight.w700,
                            ),
                            softWrap: false,
                          ),
                        ),
                      ),
                      Pinned.fromPins(
                        Pin(size: 356.0, end: 73.0),
                        Pin(size: 44.0, middle: 0.4825),
                        child:
                            // Adobe XD layer: 'john.doe@mail.com' (text)
                            Text(
                          'john.doe@mail.com',
                          style: TextStyle(
                            fontFamily: 'Arial',
                            fontSize: 40,
                            color: const Color(0xffbf0065),
                          ),
                          textAlign: TextAlign.right,
                          softWrap: false,
                        ),
                      ),
                      Pinned.fromPins(
                        Pin(size: 46.1, start: 69.2),
                        Pin(size: 45.8, middle: 0.5101),
                        child:
                            // Adobe XD layer: 'Symbol 6 – 35' (group)
                            Stack(
                          children: <Widget>[
                            // Adobe XD layer: 'Union 1' (group)
                            Stack(
                              children: <Widget>[
                                Align(
                                  alignment: Alignment.topCenter,
                                  child:
                                      // Adobe XD layer: 'Ellipse 3' (shape)
                                      Container(
                                    width: 23.0,
                                    height: 23.0,
                                    decoration: BoxDecoration(
                                      color: const Color(0xff990050),
                                      borderRadius: BorderRadius.all(
                                          Radius.elliptical(9999.0, 9999.0)),
                                    ),
                                  ),
                                ),
                                Pinned.fromPins(
                                  Pin(start: 0.0, end: 0.0),
                                  Pin(size: 17.3, end: 0.0),
                                  child:
                                      // Adobe XD layer: 'Path 6' (shape)
                                      SvgPicture.string(
                                    _svg_cby9oi,
                                    allowDrawingOutsideViewBox: true,
                                    fit: BoxFit.fill,
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
                Pinned.fromPins(
                  Pin(start: 0.0, end: 0.0),
                  Pin(size: 187.0, middle: 0.6665),
                  child:
                      // Adobe XD layer: 'Privacy' (group)
                      Stack(
                    children: <Widget>[
                      // Adobe XD layer: 'Rectangle 514' (shape)
                      Container(
                        decoration: BoxDecoration(
                          color: const Color(0xfff8ecf2),
                          borderRadius: BorderRadius.circular(25.0),
                        ),
                      ),
                      Pinned.fromPins(
                        Pin(size: 46.0, start: 69.0),
                        Pin(size: 46.1, middle: 0.5111),
                        child:
                            // Adobe XD layer: 'Symbol 50 – 5' (group)
                            Stack(
                          children: <Widget>[
                            // Adobe XD layer: 'Rectangle 118' (shape)
                            Container(
                              decoration: BoxDecoration(),
                            ),
                            Padding(
                              padding: EdgeInsets.symmetric(
                                  horizontal: 3.1, vertical: 0.0),
                              child: SizedBox.expand(
                                  child:
                                      // Adobe XD layer: 'Path 49' (shape)
                                      SvgPicture.string(
                                _svg_itgb31,
                                allowDrawingOutsideViewBox: true,
                                fit: BoxFit.fill,
                              )),
                            ),
                          ],
                        ),
                      ),
                      Align(
                        alignment: Alignment(-0.559, -0.007),
                        child: SizedBox(
                          width: 153.0,
                          height: 48.0,
                          child:
                              // Adobe XD layer: 'Privacy' (text)
                              Text(
                            'Privacy',
                            style: TextStyle(
                              fontFamily: 'Arial',
                              fontSize: 43,
                              color: const Color(0xff990050),
                              fontWeight: FontWeight.w700,
                            ),
                            softWrap: false,
                          ),
                        ),
                      ),
                      Pinned.fromPins(
                        Pin(size: 149.0, end: 70.0),
                        Pin(size: 44.0, middle: 0.4825),
                        child:
                            // Adobe XD layer: 'Only me' (text)
                            Text(
                          'Only me',
                          style: TextStyle(
                            fontFamily: 'Arial',
                            fontSize: 40,
                            color: const Color(0xffbf0065),
                          ),
                          textAlign: TextAlign.right,
                          softWrap: false,
                        ),
                      ),
                    ],
                  ),
                ),
                Pinned.fromPins(
                  Pin(start: 0.0, end: 0.0),
                  Pin(size: 188.0, end: 257.0),
                  child:
                      // Adobe XD layer: 'Block' (group)
                      Stack(
                    children: <Widget>[
                      // Adobe XD layer: 'Rectangle 512' (shape)
                      Container(
                        decoration: BoxDecoration(
                          color: const Color(0xfff8ecf2),
                          borderRadius: BorderRadius.circular(25.0),
                        ),
                      ),
                      Align(
                        alignment: Alignment(-0.577, -0.014),
                        child: SizedBox(
                          width: 117.0,
                          height: 48.0,
                          child:
                              // Adobe XD layer: 'Block' (text)
                              Text(
                            'Block',
                            style: TextStyle(
                              fontFamily: 'Arial',
                              fontSize: 43,
                              color: const Color(0xff990050),
                              fontWeight: FontWeight.w700,
                            ),
                            softWrap: false,
                          ),
                        ),
                      ),
                      Pinned.fromPins(
                        Pin(size: 46.3, start: 69.0),
                        Pin(size: 46.4, middle: 0.5085),
                        child:
                            // Adobe XD layer: 'Block' (group)
                            Stack(
                          children: <Widget>[
                            // Adobe XD layer: 'Rectangle 480' (shape)
                            Container(
                              decoration: BoxDecoration(),
                            ),
                            SizedBox.expand(
                                child:
                                    // Adobe XD layer: 'Path 145' (shape)
                                    SvgPicture.string(
                              _svg_rv89ns,
                              allowDrawingOutsideViewBox: true,
                              fit: BoxFit.fill,
                            )),
                          ],
                        ),
                      ),
                      Pinned.fromPins(
                        Pin(size: 93.0, end: 71.0),
                        Pin(size: 43.0, middle: 0.4759),
                        child:
                            // Adobe XD layer: 'None' (text)
                            Text(
                          'None',
                          style: TextStyle(
                            fontFamily: 'Arial',
                            fontSize: 39,
                            color: const Color(0xffbf0065),
                          ),
                          textAlign: TextAlign.right,
                          softWrap: false,
                        ),
                      ),
                    ],
                  ),
                ),
                Pinned.fromPins(
                  Pin(start: 0.0, end: 0.0),
                  Pin(size: 187.0, end: 0.0),
                  child:
                      // Adobe XD layer: 'Help' (group)
                      Stack(
                    children: <Widget>[
                      // Adobe XD layer: 'Rectangle 515' (shape)
                      Container(
                        color: const Color(0xfff8ecf2),
                      ),
                      Pinned.fromPins(
                        Pin(size: 46.3, start: 69.0),
                        Pin(size: 46.4, middle: 0.5092),
                        child:
                            // Adobe XD layer: 'Help' (group)
                            Stack(
                          children: <Widget>[
                            // Adobe XD layer: 'Rectangle 481' (shape)
                            Container(
                              decoration: BoxDecoration(),
                            ),
                            SizedBox.expand(
                                child:
                                    // Adobe XD layer: 'Path 146' (shape)
                                    SvgPicture.string(
                              _svg_tuqtjt,
                              allowDrawingOutsideViewBox: true,
                              fit: BoxFit.fill,
                            )),
                          ],
                        ),
                      ),
                      Align(
                        alignment: Alignment(-0.588, 0.0),
                        child: SizedBox(
                          width: 95.0,
                          height: 49.0,
                          child:
                              // Adobe XD layer: 'Help' (text)
                              Text(
                            'Help',
                            style: TextStyle(
                              fontFamily: 'Arial',
                              fontSize: 44,
                              color: const Color(0xff990050),
                              fontWeight: FontWeight.w700,
                            ),
                            softWrap: false,
                          ),
                        ),
                      ),
                      Pinned.fromPins(
                        Pin(size: 202.0, end: 75.0),
                        Pin(size: 44.0, middle: 0.4825),
                        child:
                            // Adobe XD layer: 'Questions?' (text)
                            Text(
                          'Questions?',
                          style: TextStyle(
                            fontFamily: 'Arial',
                            fontSize: 40,
                            color: const Color(0xffbf0065),
                          ),
                          textAlign: TextAlign.right,
                          softWrap: false,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          Pinned.fromPins(
            Pin(start: 0.0, end: 0.0),
            Pin(size: 196.0, start: 0.0),
            child:
                // Adobe XD layer: 'Navigation Bar' (group)
                Stack(
              children: <Widget>[
                Pinned.fromPins(
                  Pin(start: 0.0, end: 0.0),
                  Pin(size: 58.0, start: 0.0),
                  child:
                      // Adobe XD layer: 'Rectangle 68' (shape)
                      Container(
                    decoration: BoxDecoration(),
                  ),
                ),
                // Adobe XD layer: 'Rectangle 69' (shape)
                Container(
                  decoration: BoxDecoration(),
                  margin: EdgeInsets.fromLTRB(0.0, 58.0, 0.0, 0.0),
                ),
                Align(
                  alignment: Alignment(0.002, 0.329),
                  child: SizedBox(
                    width: 200.0,
                    height: 44.0,
                    child:
                        // Adobe XD layer: 'SETTINGS' (text)
                        Text(
                      'SETTINGS',
                      style: TextStyle(
                        fontFamily: 'Arial',
                        fontSize: 40,
                        color: const Color(0xffffffff),
                        fontWeight: FontWeight.w700,
                      ),
                      textAlign: TextAlign.center,
                      softWrap: false,
                    ),
                  ),
                ),
                Pinned.fromPins(
                  Pin(size: 46.0, start: 46.0),
                  Pin(size: 46.0, middle: 0.6933),
                  child:
                      // Adobe XD layer: 'Menu' (group)
                      Stack(
                    children: <Widget>[
                      // Adobe XD layer: 'Rectangle 175' (shape)
                      Container(
                        decoration: BoxDecoration(),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          Pinned.fromPins(
            Pin(size: 57.9, start: 59.0),
            Pin(size: 54.6, start: 62.0),
            child:
                // Adobe XD layer: 'Icon ionic-md-arrow…' (component)
                PageLink(
              links: [
                PageLinkInfo(),
              ],
              child: XDIconIonicMdArrowRoundBack(),
            ),
          ),
        ],
      ),
    );
  }
}

const String _svg_s3l5y1 =
    '<svg viewBox="0.0 0.0 46.1 46.1" ><path  d="M 23.48307991027832 8.861538887023926 L 7.089231491088867 25.69846534729004 L 0 46.08000183105469 L 20.38153839111328 39.43384552001953 L 36.77538681030273 23.04000091552734 L 23.48307991027832 8.861538887023926 Z M 44.30769729614258 7.532308578491211 L 38.54769134521484 1.772307872772217 C 37.21846389770508 0.4430769681930542 35.88923263549805 0 34.56000518798828 0 C 33.23077011108398 0 31.90154075622559 0.4430769681930542 30.57230949401855 1.772307872772217 L 25.69846534729004 6.646153926849365 L 38.99077224731445 20.38153839111328 L 44.30769729614258 15.06461715698242 C 45.19384765625 14.17846298217773 46.08000183105469 12.84923267364502 46.08000183105469 11.07692432403564 C 46.08000183105469 9.747693061828613 45.19384765625 8.418461799621582 44.30769729614258 7.532308578491211 Z" fill="#990050" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_ekp3i =
    '<svg viewBox="0.0 0.0 45.8 46.1" ><path transform="translate(-0.06, 0.0)" d="M 43.08250045776367 40.31999969482422 L 28.6825008392334 40.31999969482422 C 28.6825008392334 43.48800277709961 26.09050178527832 46.08000183105469 22.92250061035156 46.08000183105469 C 19.7544994354248 46.08000183105469 17.16250038146973 43.48800277709961 17.16250038146973 40.31999969482422 L 2.762500047683716 40.31999969482422 C 1.61050009727478 40.31999969482422 0.458499938249588 39.45600128173828 0.1705000400543213 38.30400085449219 C -0.117499977350235 37.15200424194336 0.1705000400543213 35.71200180053711 1.034500122070312 35.13600158691406 C 3.914499998092651 32.83200073242188 5.642500400543213 29.66400146484375 5.642500400543213 25.92000198364258 L 5.642500400543213 17.28000068664551 C 5.642500400543213 7.776000499725342 13.41849994659424 0 22.92250061035156 0 C 32.4265022277832 0 40.20249938964844 7.776000499725342 40.20249938964844 17.28000068664551 L 40.20249938964844 25.92000198364258 C 40.20249938964844 29.66400146484375 41.93050384521484 32.83200073242188 44.81050109863281 35.13600158691406 C 45.67450332641602 36 46.25050354003906 37.15200042724609 45.67450332641602 38.30400085449219 C 45.38650131225586 39.45600128173828 44.23450088500977 40.31999969482422 43.08250045776367 40.31999969482422 Z" fill="#990050" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_pmxtx =
    '<svg viewBox="0.0 0.0 43.8 46.1" ><path transform="translate(-260.0, 0.0)" d="M 281.6000366210938 28.80000114440918 C 284.76806640625 28.80000114440918 287.3600463867188 26.2080020904541 287.3600463867188 23.04000091552734 C 287.3600463867188 19.87199974060059 284.76806640625 17.28000068664551 281.6000366210938 17.28000068664551 C 278.4320068359375 17.28000068664551 275.8400268554688 19.87200164794922 275.8400268554688 23.04000091552734 C 275.8400268554688 26.2080020904541 278.4320068359375 28.80000114440918 281.6000366210938 28.80000114440918 Z M 269.7920532226562 10.36800003051758 C 271.8080444335938 8.640000343322754 274.1119995117188 7.200000286102295 276.7039794921875 6.624000072479248 L 279.0079956054688 0 L 284.7679443359375 0 L 287.0719604492188 6.624000072479248 C 289.6639404296875 7.48799991607666 291.9679565429688 8.640000343322754 293.9839477539062 10.36800003051758 L 300.8958740234375 8.928000450134277 L 303.77587890625 14.11199951171875 L 299.1679077148438 19.29599952697754 C 299.4559326171875 20.44799995422363 299.4559326171875 21.88800048828125 299.4559326171875 23.04000091552734 C 299.4559326171875 24.1919994354248 299.1679077148438 25.63199996948242 299.1679077148438 26.78400230407715 L 303.77587890625 31.96800231933594 L 300.8958740234375 37.15200424194336 L 293.9839477539062 35.71200180053711 C 291.9678955078125 37.44000244140625 289.6639404296875 38.8800048828125 287.0719604492188 39.45600509643555 L 284.7679443359375 46.08000183105469 L 279.0079956054688 46.08000183105469 L 276.7039794921875 39.45600128173828 C 274.1119995117188 38.59199905395508 271.8079833984375 37.44000244140625 269.7920532226562 35.71200180053711 L 262.8800659179688 37.15200042724609 L 260.0000610351562 31.9680004119873 L 264.6080322265625 26.78399848937988 C 264.320068359375 25.63199996948242 264.320068359375 24.1919994354248 264.320068359375 23.03999900817871 C 264.320068359375 21.88799667358398 264.6080322265625 20.447998046875 264.6080322265625 19.29599761962891 L 260.0000610351562 14.11200046539307 L 262.8800659179688 8.928000450134277 L 269.7920532226562 10.36800003051758 Z" fill="#990050" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_cby9oi =
    '<svg viewBox="0.0 28.8 46.1 17.3" ><path transform="translate(0.0, 18.8)" d="M 23.04000091552734 10.00000190734863 C 10.36800003051758 10.00000190734863 0 15.18400192260742 0 21.52000045776367 L 0 27.28000259399414 L 46.08000183105469 27.28000259399414 L 46.08000183105469 21.52000045776367 C 46.08000183105469 15.18400192260742 35.71200180053711 10.00000190734863 23.04000091552734 10.00000190734863 Z" fill="#990050" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_itgb31 =
    '<svg viewBox="2.9 0.0 40.3 46.1" ><path transform="translate(2.88, 0.0)" d="M 20.15999984741211 23.04000091552734 C 23.3280029296875 23.04000091552734 25.92000198364258 25.63199996948242 25.92000198364258 28.80000114440918 C 25.92000198364258 31.96800231933594 23.3280029296875 34.56000137329102 20.15999984741211 34.56000137329102 C 16.99199867248535 34.56000137329102 14.40000057220459 31.96800231933594 14.40000057220459 28.80000114440918 C 14.40000057220459 25.63199996948242 16.99200057983398 23.04000091552734 20.15999984741211 23.04000091552734 Z M 20.15999984741211 5.760000228881836 C 16.99200057983398 5.760000228881836 14.40000057220459 8.35200023651123 14.40000057220459 11.52000045776367 L 25.92000198364258 11.52000045776367 C 25.92000198364258 8.35200023651123 23.3280029296875 5.760000228881836 20.15999984741211 5.760000228881836 Z M 34.56000137329102 46.08000183105469 L 5.760000228881836 46.08000183105469 C 2.592000007629395 46.08000183105469 0 43.48800277709961 0 40.31999969482422 L 0 17.28000068664551 C 0 14.11200046539307 2.592000007629395 11.52000045776367 5.760000228881836 11.52000045776367 L 8.640000343322754 11.52000045776367 C 8.640000343322754 5.184000015258789 13.82400131225586 0 20.15999984741211 0 C 26.49600028991699 0 31.68000030517578 5.184000015258789 31.68000030517578 11.52000045776367 L 34.56000137329102 11.52000045776367 C 37.72800445556641 11.52000045776367 40.31999969482422 14.11200046539307 40.31999969482422 17.28000068664551 L 40.31999969482422 40.31999969482422 C 40.31999969482422 43.48800277709961 37.72800445556641 46.08000183105469 34.56000137329102 46.08000183105469 Z" fill="#990050" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_rv89ns =
    '<svg viewBox="0.0 0.0 46.1 46.1" ><path  d="M 23.04000091552734 0 C 10.36800098419189 0 0 10.36800098419189 0 23.04000091552734 C 0 35.71200180053711 10.36800098419189 46.08000183105469 23.04000091552734 46.08000183105469 C 35.71200180053711 46.08000183105469 46.08000183105469 35.71200180053711 46.08000183105469 23.04000091552734 C 46.08000183105469 10.36800098419189 35.71200180053711 0 23.04000091552734 0 Z M 6.91200065612793 23.04000091552734 C 6.91200065612793 19.81440162658691 7.833600521087646 16.81920051574707 9.44640064239502 14.28480052947998 L 31.79520034790039 36.63360214233398 C 29.26080131530762 38.24640274047852 26.26560020446777 39.16800308227539 23.04000091552734 39.16800308227539 C 14.05440044403076 39.16800308227539 6.91200065612793 32.02560043334961 6.91200065612793 23.04000091552734 Z M 36.63360214233398 31.79520034790039 L 14.28480052947998 9.44640064239502 C 16.81920051574707 7.833600521087646 19.81440162658691 6.91200065612793 23.04000091552734 6.91200065612793 C 32.02560043334961 6.91200065612793 39.16800308227539 14.05440044403076 39.16800308227539 23.04000091552734 C 39.16800308227539 26.26560020446777 38.24640274047852 29.26080131530762 36.63360214233398 31.79520034790039 Z" fill="#990050" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_tuqtjt =
    '<svg viewBox="0.0 0.0 46.1 46.1" ><path  d="M 23.04000091552734 0 C 10.36800098419189 0 0 10.36800098419189 0 23.04000091552734 C 0 35.71200180053711 10.36800098419189 46.08000183105469 23.04000091552734 46.08000183105469 C 35.71200180053711 46.08000183105469 46.08000183105469 35.71200180053711 46.08000183105469 23.04000091552734 C 46.08000183105469 10.36800098419189 35.71200180053711 0 23.04000091552734 0 Z M 22.80959892272949 38.24640274047852 C 20.96640014648438 38.24640274047852 19.5840015411377 36.8640022277832 19.5840015411377 35.02080535888672 C 19.5840015411377 33.1776008605957 20.96640205383301 31.79520416259766 22.80959892272949 31.79520416259766 C 24.65280151367188 31.79520416259766 26.03520011901855 33.17760467529297 26.03520011901855 35.02080535888672 C 26.03520011901855 36.8640022277832 24.65280151367188 38.24640274047852 22.80959892272949 38.24640274047852 Z M 29.03040313720703 20.27520179748535 L 26.49600028991699 23.04000091552734 C 25.80480194091797 23.73120307922363 25.57440185546875 24.42240333557129 25.57440185546875 25.11360168457031 C 25.57440185546875 26.72640037536621 24.19200325012207 27.87839889526367 22.80960273742676 27.87839889526367 C 21.19680213928223 27.87839889526367 20.04480171203613 26.72640037536621 20.04480171203613 25.11360168457031 C 20.04480171203613 23.731201171875 20.27520370483398 22.57920074462891 21.88800239562988 20.96640014648438 L 23.96159934997559 18.4320011138916 C 25.11360168457031 17.04960060119629 25.57440185546875 16.12800025939941 25.57440185546875 15.20640087127686 C 25.57440185546875 13.59360122680664 24.42239952087402 12.67200088500977 23.03999900817871 12.67200088500977 C 21.6575984954834 12.67200088500977 20.73599815368652 13.36320114135742 20.27519989013672 14.74560165405273 C 19.5840015411377 15.8976001739502 18.66240310668945 16.35840034484863 17.51040077209473 16.35840034484863 C 16.12800025939941 16.35840034484863 14.97600173950195 15.43680095672607 14.97600173950195 13.82400131225586 C 14.97600173950195 13.59360122680664 14.97600173950195 13.13280010223389 15.20640087127686 12.67200088500977 C 16.12800025939941 9.907200813293457 18.89280128479004 7.833600521087646 23.04000091552734 7.833600521087646 C 27.87840270996094 7.833600521087646 31.10400199890137 11.05920124053955 31.10400199890137 15.20640087127686 C 31.10400199890137 17.04960060119629 30.41280174255371 18.66240310668945 29.03040313720703 20.27520179748535 Z" fill="#990050" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
