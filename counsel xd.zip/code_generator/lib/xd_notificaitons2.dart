import 'package:flutter/material.dart';
import 'package:adobe_xd/pinned.dart';
import './xd_drag_bar.dart';
import 'package:adobe_xd/page_link.dart';
import './xd_logout.dart';
import './xd_settings.dart';
import './xd_feed.dart';
import './xd_courses.dart';
import './xd_career_progess.dart';
import './xd_profile.dart';

class XDNotificaitons2 extends StatelessWidget {
  XDNotificaitons2({
    Key? key,
  }) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: <Widget>[
          Container(
            decoration: BoxDecoration(
              color: const Color(0xffffffff),
              borderRadius: BorderRadius.only(
                topLeft: Radius.circular(74.0),
                topRight: Radius.circular(74.0),
              ),
              boxShadow: [
                BoxShadow(
                  color: const Color(0x29000000),
                  offset: Offset(0, -1),
                  blurRadius: 10,
                ),
              ],
            ),
            margin: EdgeInsets.fromLTRB(0.0, 213.0, 0.0, 0.0),
          ),
          Pinned.fromPins(
            Pin(size: 1080.0, end: -388.0),
            Pin(size: 777.0, end: 0.0),
            child: Stack(
              children: <Widget>[
                Padding(
                  padding: EdgeInsets.fromLTRB(126.2, 3.0, -289.2, -498.0),
                  child: Transform.rotate(
                    angle: 0.1047,
                    child: Stack(
                      children: <Widget>[
                        Align(
                          alignment: Alignment.topRight,
                          child: Container(
                            width: 858.0,
                            height: 775.0,
                            decoration: BoxDecoration(
                              color: const Color(0x13000000),
                              borderRadius: BorderRadius.all(
                                  Radius.elliptical(9999.0, 9999.0)),
                            ),
                          ),
                        ),
                        Align(
                          alignment: Alignment.bottomLeft,
                          child: Container(
                            width: 857.0,
                            height: 774.0,
                            decoration: BoxDecoration(
                              color: const Color(0x13000000),
                              borderRadius: BorderRadius.all(
                                  Radius.elliptical(9999.0, 9999.0)),
                            ),
                          ),
                        ),
                        Pinned.fromPins(
                          Pin(size: 857.0, end: 101.0),
                          Pin(size: 775.0, middle: 0.4789),
                          child: Container(
                            decoration: BoxDecoration(
                              color: const Color(0x13000000),
                              borderRadius: BorderRadius.all(
                                  Radius.elliptical(9999.0, 9999.0)),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                Container(
                  color: const Color(0x80ffffff),
                ),
              ],
            ),
          ),
          Align(
            alignment: Alignment(-1.0, -0.366),
            child: SizedBox(
              width: 893.0,
              height: 387.0,
              child: Stack(
                children: <Widget>[
                  Pinned.fromPins(
                    Pin(size: 533.4, start: -280.1),
                    Pin(size: 564.7, start: -332.7),
                    child: Transform.rotate(
                      angle: -0.1745,
                      child: Stack(
                        children: <Widget>[
                          Align(
                            alignment: Alignment.topRight,
                            child: Container(
                              width: 369.0,
                              height: 369.0,
                              decoration: BoxDecoration(
                                color: const Color(0x13990050),
                                borderRadius: BorderRadius.all(
                                    Radius.elliptical(9999.0, 9999.0)),
                              ),
                            ),
                          ),
                          Align(
                            alignment: Alignment.bottomLeft,
                            child: Container(
                              width: 369.0,
                              height: 369.0,
                              decoration: BoxDecoration(
                                color: const Color(0x13990050),
                                borderRadius: BorderRadius.all(
                                    Radius.elliptical(9999.0, 9999.0)),
                              ),
                            ),
                          ),
                          Pinned.fromPins(
                            Pin(size: 369.5, end: 61.4),
                            Pin(size: 369.5, middle: 0.5452),
                            child: Container(
                              decoration: BoxDecoration(
                                color: const Color(0x13990050),
                                borderRadius: BorderRadius.all(
                                    Radius.elliptical(9999.0, 9999.0)),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  Container(
                    decoration: BoxDecoration(
                      color: const Color(0xbfffffff),
                      borderRadius: BorderRadius.circular(74.0),
                    ),
                  ),
                ],
              ),
            ),
          ),
          Pinned.fromPins(
            Pin(start: 0.0, end: 0.0),
            Pin(size: 277.0, end: 0.0),
            child: Stack(
              children: <Widget>[
                Pinned.fromPins(
                  Pin(size: 500.0, end: -293.0),
                  Pin(start: 52.0, end: -239.0),
                  child: Transform.rotate(
                    angle: 2.8274,
                    child:
                        // Adobe XD layer: 'pink circle' (group)
                        Stack(
                      children: <Widget>[
                        Align(
                          alignment: Alignment.topRight,
                          child: Container(
                            width: 343.0,
                            height: 343.0,
                            decoration: BoxDecoration(
                              color: const Color(0x78bf0065),
                              borderRadius: BorderRadius.all(
                                  Radius.elliptical(9999.0, 9999.0)),
                            ),
                          ),
                        ),
                        Align(
                          alignment: Alignment.bottomLeft,
                          child: Container(
                            width: 343.0,
                            height: 343.0,
                            decoration: BoxDecoration(
                              color: const Color(0x78d171a4),
                              borderRadius: BorderRadius.all(
                                  Radius.elliptical(9999.0, 9999.0)),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                Container(
                  color: const Color(0xffffffff),
                ),
              ],
            ),
          ),
          Align(
            alignment: Alignment(0.001, -0.511),
            child: SizedBox(
              width: 153.0,
              height: 13.0,
              child:
                  // Adobe XD layer: 'drag_bar' (component)
                  PageLink(
                links: [
                  PageLinkInfo(),
                ],
                child: XDDragBar(),
              ),
            ),
          ),
          Pinned.fromPins(
            Pin(start: 133.0, end: 132.0),
            Pin(size: 79.0, end: 79.0),
            child:
                // Adobe XD layer: 'logout' (component)
                XDLogout(),
          ),
          Pinned.fromPins(
            Pin(start: 133.0, end: 132.0),
            Pin(size: 79.0, middle: 0.7939),
            child:
                // Adobe XD layer: 'settings' (component)
                XDSettings(),
          ),
          Pinned.fromPins(
            Pin(start: 133.0, end: 132.0),
            Pin(size: 79.0, middle: 0.6776),
            child:
                // Adobe XD layer: 'feed' (component)
                XDFeed(),
          ),
          Pinned.fromPins(
            Pin(start: 133.0, end: 132.0),
            Pin(size: 79.0, middle: 0.5684),
            child:
                // Adobe XD layer: 'Courses' (component)
                XDCourses(),
          ),
          Pinned.fromPins(
            Pin(start: 133.0, end: 132.0),
            Pin(size: 79.0, middle: 0.4602),
            child:
                // Adobe XD layer: 'career_progess' (component)
                XDCareerProgess(),
          ),
          Pinned.fromPins(
            Pin(start: 133.0, end: 132.0),
            Pin(size: 79.0, middle: 0.3551),
            child:
                // Adobe XD layer: 'profile' (component)
                XDProfile(),
          ),
        ],
      ),
    );
  }
}
