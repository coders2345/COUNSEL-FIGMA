import 'package:flutter/material.dart';
import 'package:adobe_xd/pinned.dart';
import 'package:flutter_svg/flutter_svg.dart';

class XDRememberMe extends StatelessWidget {
  XDRememberMe({
    Key? key,
  }) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return Stack(
      children: <Widget>[
        Pinned.fromPins(
          Pin(start: 47.0, end: 0.0),
          Pin(size: 49.0, middle: 0.5),
          child: Text(
            'Remember me.',
            style: TextStyle(
              fontFamily: 'Calibri',
              fontSize: 40,
              color: const Color(0xffd171a4),
              fontWeight: FontWeight.w300,
            ),
            softWrap: false,
          ),
        ),
        Align(
          alignment: Alignment.centerLeft,
          child: SizedBox(
            width: 27.0,
            height: 27.0,
            child:
                // Adobe XD layer: 'Icon ionic-ios-chec…' (group)
                Stack(
              children: <Widget>[
                SizedBox.expand(
                    child: SvgPicture.string(
                  _svg_dcg7b,
                  allowDrawingOutsideViewBox: true,
                  fit: BoxFit.fill,
                )),
              ],
            ),
          ),
        ),
      ],
    );
  }
}

const String _svg_dcg7b =
    '<svg viewBox="4.5 4.5 27.0 27.0" ><path  d="M 29.25 4.5 L 6.75 4.5 C 5.50546932220459 4.5 4.5 5.50546932220459 4.5 6.75 L 4.5 29.25 C 4.5 30.49453353881836 5.50546932220459 31.5 6.75 31.5 L 29.25 31.5 C 30.49453353881836 31.5 31.5 30.49453353881836 31.5 29.25 L 31.5 6.75 C 31.5 5.50546932220459 30.49453353881836 4.5 29.25 4.5 Z M 29.53125190734863 28.96875190734863 C 29.53125190734863 29.27812957763672 29.27812957763672 29.53125190734863 28.96875190734863 29.53125190734863 L 7.031250953674316 29.53125190734863 C 6.72187614440918 29.53125190734863 6.46875 29.27812957763672 6.46875 28.96875190734863 L 6.46875 7.031250953674316 C 6.46875 6.72187614440918 6.72187614440918 6.46875 7.031250953674316 6.46875 L 28.96875190734863 6.46875 C 29.27812957763672 6.46875 29.53125190734863 6.72187614440918 29.53125190734863 7.031250953674316 L 29.53125190734863 28.96875190734863 Z" fill="#bf0065" stroke="none" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
