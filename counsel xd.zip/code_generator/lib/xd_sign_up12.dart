import 'package:flutter/material.dart';
import 'package:adobe_xd/pinned.dart';
import 'package:adobe_xd/blend_mask.dart';
import './xd_first_name.dart';
import './xd_next.dart';
import './xd_icon_ionic_md_arrow_round_back.dart';

class XDSignUp12 extends StatelessWidget {
  XDSignUp12({
    Key? key,
  }) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xffffffff),
      body: Stack(
        children: <Widget>[
          Pinned.fromPins(
            Pin(size: 61.0, end: 92.0),
            Pin(size: 62.0, middle: 0.6244),
            child: Container(
              decoration: BoxDecoration(
                color: const Color(0xffbf0065),
                borderRadius:
                    BorderRadius.all(Radius.elliptical(9999.0, 9999.0)),
              ),
            ),
          ),
          Pinned.fromPins(
            Pin(size: 61.0, start: 82.0),
            Pin(size: 62.0, end: 336.0),
            child: Container(
              decoration: BoxDecoration(
                color: const Color(0xffeb3b98),
                borderRadius:
                    BorderRadius.all(Radius.elliptical(9999.0, 9999.0)),
              ),
            ),
          ),
          Pinned.fromPins(
            Pin(start: 0.0, end: 0.0),
            Pin(size: 1294.0, start: 0.0),
            child: Stack(
              children: <Widget>[
                Container(
                  color: const Color(0xffa20a5a),
                ),
                // Adobe XD layer: 'pexels-pixabay-2202…' (shape)
                Container(
                  decoration: BoxDecoration(
                    image: DecorationImage(
                      image: const AssetImage(''),
                      fit: BoxFit.fill,
                      colorFilter: new ColorFilter.mode(
                          Colors.black.withOpacity(0.73), BlendMode.dstIn),
                    ),
                  ),
                  margin: EdgeInsets.fromLTRB(-369.0, 0.0, -370.0, 0.0),
                ),
                Stack(
                  children: <Widget>[
                    Pinned.fromPins(
                      Pin(size: 699.0, start: -17.0),
                      Pin(size: 646.0, end: -416.0),
                      child: Container(
                        decoration: BoxDecoration(
                          color: const Color(0x40000000),
                          borderRadius: BorderRadius.all(
                              Radius.elliptical(9999.0, 9999.0)),
                        ),
                      ),
                    ),
                    Pinned.fromPins(
                      Pin(size: 699.0, end: -93.0),
                      Pin(size: 648.0, end: -238.0),
                      child: Container(
                        decoration: BoxDecoration(
                          color: const Color(0x40000000),
                          borderRadius: BorderRadius.all(
                              Radius.elliptical(9999.0, 9999.0)),
                        ),
                      ),
                    ),
                    Pinned.fromPins(
                      Pin(size: 699.0, end: -415.0),
                      Pin(size: 646.0, end: 185.0),
                      child: Container(
                        decoration: BoxDecoration(
                          color: const Color(0x40000000),
                          borderRadius: BorderRadius.all(
                              Radius.elliptical(9999.0, 9999.0)),
                          border: Border.all(
                              width: 1.0, color: const Color(0x40707070)),
                        ),
                      ),
                    ),
                    Container(
                      decoration: BoxDecoration(
                        color: const Color(0xffffffff),
                        border: Border.all(
                            width: 1.0, color: const Color(0xff707070)),
                      ),
                    ),
                  ],
                ),
                Container(
                  decoration: BoxDecoration(
                    color: const Color(0xffffffff),
                    borderRadius: BorderRadius.only(
                      bottomRight: Radius.circular(250.0),
                    ),
                  ),
                ),
              ],
            ),
          ),
          Pinned.fromPins(
            Pin(size: 593.0, start: 104.0),
            Pin(size: 91.0, middle: 0.4957),
            child: Text(
              'Set your password.',
              style: TextStyle(
                fontFamily: 'Calibri',
                fontSize: 75,
                color: const Color(0xffe4e4e4),
                fontWeight: FontWeight.w700,
              ),
              softWrap: false,
            ),
          ),
          Pinned.fromPins(
            Pin(start: 0.0, end: 0.0),
            Pin(size: 442.0, end: 0.0),
            child: Stack(
              children: <Widget>[
                Transform.rotate(
                  angle: -0.1396,
                  child:
                      // Adobe XD layer: 'circles' (shape)
                      BlendMask(
                    blendMode: BlendMode.luminosity,
                    child: Container(
                      decoration: BoxDecoration(
                        image: DecorationImage(
                          image: const AssetImage(''),
                          fit: BoxFit.cover,
                          colorFilter: new ColorFilter.mode(
                              Colors.black.withOpacity(0.15), BlendMode.dstIn),
                        ),
                        border: Border.all(
                            width: 1.0, color: const Color(0x00000000)),
                      ),
                      margin: EdgeInsets.fromLTRB(-73.0, 16.0, -601.0, -244.0),
                    ),
                  ),
                ),
                Container(
                  decoration: BoxDecoration(
                    color: const Color(0x26ffffff),
                    border:
                        Border.all(width: 1.0, color: const Color(0x26707070)),
                  ),
                ),
              ],
            ),
          ),
          Pinned.fromPins(
            Pin(start: 0.0, end: 0.0),
            Pin(size: 1327.0, end: 0.0),
            child: Stack(
              children: <Widget>[
                Pinned.fromPins(
                  Pin(size: 500.0, end: -293.0),
                  Pin(size: 464.0, end: -144.0),
                  child: Transform.rotate(
                    angle: 2.8274,
                    child:
                        // Adobe XD layer: 'pink circle' (group)
                        Stack(
                      children: <Widget>[
                        Align(
                          alignment: Alignment.topRight,
                          child: Container(
                            width: 343.0,
                            height: 343.0,
                            decoration: BoxDecoration(
                              color: const Color(0xffbf0065),
                              borderRadius: BorderRadius.all(
                                  Radius.elliptical(9999.0, 9999.0)),
                            ),
                          ),
                        ),
                        Align(
                          alignment: Alignment.bottomLeft,
                          child: Container(
                            width: 343.0,
                            height: 343.0,
                            decoration: BoxDecoration(
                              color: const Color(0xffd171a4),
                              borderRadius: BorderRadius.all(
                                  Radius.elliptical(9999.0, 9999.0)),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                Container(
                  decoration: BoxDecoration(
                    color: const Color(0xffffffff),
                    border:
                        Border.all(width: 1.0, color: const Color(0xff707070)),
                  ),
                ),
              ],
            ),
          ),
          Pinned.fromPins(
            Pin(start: 112.0, end: 111.0),
            Pin(size: 147.0, middle: 0.6582),
            child:
                // Adobe XD layer: 'password' (component)
                XDFirstName(),
          ),
          Pinned.fromPins(
            Pin(start: 112.0, end: 111.0),
            Pin(size: 147.0, middle: 0.76),
            child:
                // Adobe XD layer: 'retype password' (component)
                XDFirstName(),
          ),
          Pinned.fromPins(
            Pin(start: 112.0, end: 111.0),
            Pin(size: 114.0, end: 279.0),
            child:
                // Adobe XD layer: 'next' (component)
                XDNext(),
          ),
          Pinned.fromPins(
            Pin(size: 57.9, start: 59.0),
            Pin(size: 54.6, start: 62.0),
            child:
                // Adobe XD layer: 'Icon ionic-md-arrow…' (component)
                XDIconIonicMdArrowRoundBack(),
          ),
          Pinned.fromPins(
            Pin(size: 416.0, end: 111.0),
            Pin(size: 49.0, middle: 0.8014),
            child: Text(
              'Password does not match',
              style: TextStyle(
                fontFamily: 'Calibri',
                fontSize: 40,
                color: Colors.transparent,
              ),
              softWrap: false,
            ),
          ),
        ],
      ),
    );
  }
}
