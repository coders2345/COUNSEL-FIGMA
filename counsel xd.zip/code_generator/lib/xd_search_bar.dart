import 'package:flutter/material.dart';
import 'package:adobe_xd/pinned.dart';
import './xd_first_name.dart';

class XDSearchBar extends StatelessWidget {
  XDSearchBar({
    Key? key,
  }) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: <Widget>[
          Pinned.fromPins(
            Pin(start: 106.0, end: 106.0),
            Pin(size: 797.0, start: 153.0),
            child: Container(
              decoration: BoxDecoration(
                color: Colors.transparent,
                borderRadius: BorderRadius.circular(38.0),
                border: Border.all(width: 1.0, color: Colors.transparent),
              ),
            ),
          ),
          Pinned.fromPins(
            Pin(start: 106.0, end: 106.0),
            Pin(size: 147.0, start: 153.0),
            child:
                // Adobe XD layer: 'SEARCH BAR' (component)
                XDFirstName(),
          ),
        ],
      ),
    );
  }
}
