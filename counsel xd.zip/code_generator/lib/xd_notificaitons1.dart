import 'package:flutter/material.dart';

class XDNotificaitons1 extends StatelessWidget {
  XDNotificaitons1({
    Key? key,
  }) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xffffffff),
      body: Stack(
        children: <Widget>[],
      ),
    );
  }
}
