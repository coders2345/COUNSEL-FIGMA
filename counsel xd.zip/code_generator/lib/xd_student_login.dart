import 'package:flutter/material.dart';
import 'package:adobe_xd/pinned.dart';
import 'package:adobe_xd/blend_mask.dart';
import './xd_icon_ionic_md_arrow_round_back.dart';
import './xd_student_button.dart';
import './xd_home_cont.dart';
import 'package:adobe_xd/page_link.dart';
import './xd_forgot_password1.dart';
import './xd_first_name.dart';
import './xd_remember_me.dart';

class XDStudentLogin extends StatelessWidget {
  XDStudentLogin({
    Key? key,
  }) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xffffffff),
      body: Stack(
        children: <Widget>[
          Pinned.fromPins(
            Pin(start: 0.0, end: 0.0),
            Pin(size: 1398.0, start: 0.0),
            child: Stack(
              children: <Widget>[
                Container(
                  color: const Color(0xffa20a5a),
                ),
                Stack(
                  children: <Widget>[
                    Pinned.fromPins(
                      Pin(start: 83.0, end: -139.0),
                      Pin(size: 1590.0, end: -588.0),
                      child:
                          // Adobe XD layer: 'circles' (shape)
                          BlendMask(
                        blendMode: BlendMode.luminosity,
                        child: Container(
                          decoration: BoxDecoration(
                            image: DecorationImage(
                              image: const AssetImage(''),
                              fit: BoxFit.cover,
                            ),
                            border: Border.all(
                                width: 1.0, color: const Color(0x00000000)),
                          ),
                        ),
                      ),
                    ),
                    Container(
                      decoration: BoxDecoration(
                        color: const Color(0xffffffff),
                        border: Border.all(
                            width: 1.0, color: const Color(0xff707070)),
                      ),
                    ),
                  ],
                ),
                Container(
                  decoration: BoxDecoration(
                    color: const Color(0xffffffff),
                    borderRadius: BorderRadius.only(
                      bottomLeft: Radius.circular(350.0),
                    ),
                  ),
                ),
              ],
            ),
          ),
          Pinned.fromPins(
            Pin(start: 0.0, end: 0.0),
            Pin(size: 1398.0, start: 0.0),
            child: Stack(
              children: <Widget>[
                BlendMask(
                  blendMode: BlendMode.softLight,
                  child: Stack(
                    children: <Widget>[
                      Container(
                        color: const Color(0x29a20a5a),
                      ),
                      Stack(
                        children: <Widget>[
                          Pinned.fromPins(
                            Pin(start: 83.0, end: -139.0),
                            Pin(size: 1590.0, end: -588.0),
                            child:
                                // Adobe XD layer: 'circles' (shape)
                                BlendMask(
                              blendMode: BlendMode.luminosity,
                              child: Container(
                                decoration: BoxDecoration(
                                  image: DecorationImage(
                                    image: const AssetImage(''),
                                    fit: BoxFit.cover,
                                    colorFilter: new ColorFilter.mode(
                                        Colors.black.withOpacity(0.8),
                                        BlendMode.dstIn),
                                  ),
                                  border: Border.all(
                                      width: 1.0,
                                      color: const Color(0x00000000)),
                                ),
                              ),
                            ),
                          ),
                          Container(
                            decoration: BoxDecoration(
                              color: const Color(0xccffffff),
                              border: Border.all(
                                  width: 1.0, color: const Color(0xcc707070)),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                Container(
                  decoration: BoxDecoration(
                    color: const Color(0xffffffff),
                    borderRadius: BorderRadius.only(
                      bottomLeft: Radius.circular(350.0),
                    ),
                  ),
                ),
              ],
            ),
          ),
          Pinned.fromPins(
            Pin(start: 0.0, end: 0.0),
            Pin(size: 1327.0, end: 0.0),
            child: Stack(
              children: <Widget>[
                Transform.rotate(
                  angle: -0.1047,
                  child:
                      // Adobe XD layer: 'circles' (shape)
                      Container(
                    decoration: BoxDecoration(
                      image: DecorationImage(
                        image: const AssetImage(''),
                        fit: BoxFit.cover,
                        colorFilter: new ColorFilter.mode(
                            Colors.black.withOpacity(0.12), BlendMode.dstIn),
                      ),
                      border: Border.all(
                          width: 1.0, color: const Color(0x00000000)),
                    ),
                    margin: EdgeInsets.fromLTRB(-30.0, 17.0, -644.0, -547.0),
                  ),
                ),
                Pinned.fromPins(
                  Pin(size: 437.0, end: -55.0),
                  Pin(size: 382.0, end: -309.0),
                  child:
                      // Adobe XD layer: 'pink circle' (group)
                      Stack(
                    children: <Widget>[
                      Pinned.fromPins(
                        Pin(size: 343.0, end: 0.0),
                        Pin(start: 0.0, end: 39.0),
                        child: Container(
                          decoration: BoxDecoration(
                            color: const Color(0x1fbf0065),
                            borderRadius: BorderRadius.all(
                                Radius.elliptical(9999.0, 9999.0)),
                          ),
                        ),
                      ),
                      Pinned.fromPins(
                        Pin(size: 343.0, start: 0.0),
                        Pin(start: 39.0, end: 0.0),
                        child: Container(
                          decoration: BoxDecoration(
                            color: const Color(0x1fd171a4),
                            borderRadius: BorderRadius.all(
                                Radius.elliptical(9999.0, 9999.0)),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                Container(
                  decoration: BoxDecoration(
                    color: const Color(0x1fffffff),
                    border:
                        Border.all(width: 1.0, color: const Color(0x1f707070)),
                  ),
                ),
              ],
            ),
          ),
          Pinned.fromPins(
            Pin(start: 0.0, end: 0.0),
            Pin(size: 1327.0, end: 0.0),
            child: Stack(
              children: <Widget>[
                Pinned.fromPins(
                  Pin(size: 536.0, end: -154.0),
                  Pin(size: 407.0, end: -309.0),
                  child:
                      // Adobe XD layer: 'pink circle' (group)
                      Stack(
                    children: <Widget>[
                      Align(
                        alignment: Alignment.topRight,
                        child: Container(
                          width: 343.0,
                          height: 343.0,
                          decoration: BoxDecoration(
                            color: const Color(0xffbf0065),
                            borderRadius: BorderRadius.all(
                                Radius.elliptical(9999.0, 9999.0)),
                          ),
                        ),
                      ),
                      Align(
                        alignment: Alignment.bottomLeft,
                        child: Container(
                          width: 343.0,
                          height: 343.0,
                          decoration: BoxDecoration(
                            color: const Color(0xffd171a4),
                            borderRadius: BorderRadius.all(
                                Radius.elliptical(9999.0, 9999.0)),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                Container(
                  decoration: BoxDecoration(
                    color: const Color(0xffffffff),
                    border:
                        Border.all(width: 1.0, color: const Color(0xff707070)),
                  ),
                ),
              ],
            ),
          ),
          Pinned.fromPins(
            Pin(size: 57.9, start: 59.0),
            Pin(size: 54.6, start: 62.0),
            child:
                // Adobe XD layer: 'Icon ionic-md-arrow…' (component)
                XDIconIonicMdArrowRoundBack(),
          ),
          Pinned.fromPins(
            Pin(size: 857.0, start: 112.0),
            Pin(size: 669.0, start: 1466.0),
            child: Stack(
              children: <Widget>[
                Pinned.fromPins(
                  Pin(start: 0.0, end: 0.0),
                  Pin(size: 114.0, middle: 0.8),
                  child:
                      // Adobe XD layer: 'sign in button' (component)
                      PageLink(
                    links: [
                      PageLinkInfo(
                        ease: Curves.easeOut,
                        duration: 0.3,
                        pageBuilder: () => XDHomeCont(),
                      ),
                    ],
                    child: XDStudentButton(),
                  ),
                ),
                Align(
                  alignment: Alignment.bottomLeft,
                  child: SizedBox(
                    width: 434.0,
                    height: 61.0,
                    child: PageLink(
                      links: [
                        PageLinkInfo(
                          ease: Curves.easeOut,
                          duration: 0.8,
                          pageBuilder: () => XDForgotPassword1(),
                        ),
                      ],
                      child: Text(
                        'Forgotten password?',
                        style: TextStyle(
                          fontFamily: 'Calibri',
                          fontSize: 50,
                          color: const Color(0xff9f0054),
                          fontWeight: FontWeight.w700,
                        ),
                        softWrap: false,
                      ),
                    ),
                  ),
                ),
                Pinned.fromPins(
                  Pin(start: 0.0, end: 0.0),
                  Pin(size: 147.0, start: 0.0),
                  child:
                      // Adobe XD layer: 'username,no,email' (component)
                      XDFirstName(),
                ),
                Pinned.fromPins(
                  Pin(start: 0.0, end: 0.0),
                  Pin(size: 147.0, middle: 0.3774),
                  child:
                      // Adobe XD layer: 'password' (component)
                      XDFirstName(),
                ),
              ],
            ),
          ),
          Pinned.fromPins(
            Pin(start: 478.0, end: 111.0),
            Pin(size: 183.0, middle: 0.5708),
            child: Text(
              'Student',
              style: TextStyle(
                fontFamily: 'Calibri',
                fontSize: 150,
                color: const Color(0xffffffff),
                fontWeight: FontWeight.w700,
              ),
              softWrap: false,
            ),
          ),
          Pinned.fromPins(
            Pin(size: 295.0, start: 112.0),
            Pin(size: 49.0, end: 399.0),
            child:
                // Adobe XD layer: 'remember me' (component)
                XDRememberMe(),
          ),
          Pinned.fromPins(
            Pin(size: 847.0, start: 65.0),
            Pin(size: 182.0, start: 210.0),
            child: Text(
              'Percieve your career in the \nright path.',
              style: TextStyle(
                fontFamily: 'Calibri',
                fontSize: 75,
                color: const Color(0xd9ffffff),
                fontWeight: FontWeight.w700,
              ),
              softWrap: false,
            ),
          ),
          Pinned.fromPins(
            Pin(start: 59.0, end: 140.0),
            Pin(size: 182.0, middle: 0.2898),
            child: Text(
              'Log in to view the numerous \npossibilities of careers.',
              style: TextStyle(
                fontFamily: 'Calibri',
                fontSize: 75,
                color: const Color(0xd9ffffff),
              ),
              softWrap: false,
            ),
          ),
          Pinned.fromPins(
            Pin(size: 276.0, end: 107.0),
            Pin(size: 49.0, end: 399.0),
            child: Text(
              'Password wrong.',
              style: TextStyle(
                fontFamily: 'Calibri',
                fontSize: 40,
                color: Colors.transparent,
              ),
              softWrap: false,
            ),
          ),
        ],
      ),
    );
  }
}
